(function () {
  var data = {
    'Transaction ID': '', 'Member Name': '', 'Member ID': '', 'Date of Birth': '',
    'Gender': '', 'Address': '', 'Group Number': '', 'Plan Begin Date': '',
    'Plan Name': '', 'Payer': '', 'Coverage Status': '', 'Identifier Code': ''
  };

  var titleEl = document.querySelector('.summary__value');
  if (titleEl) {
    var t = (titleEl.innerText || '').trim();
    if (/Transaction ID/i.test(t)) data['Transaction ID'] = t.replace(/Transaction ID:?/i, '').trim();
  }
  if (!data['Transaction ID']) {
    var m0 = (document.body.innerText || '').match(/Transaction ID[:\s]*([A-Z0-9\-]+)/i);
    if (m0) data['Transaction ID'] = m0[1].trim();
  }

  document.querySelectorAll('.summary__group').forEach(function (group) {
    var labelEl = group.querySelector('.summary__label');
    var valueEl = group.querySelector('.summary__value');
    var label = (labelEl ? labelEl.innerText : '').trim();
    var value = (valueEl ? valueEl.innerText : '').trim().replace(/\n+/g, ' ');
    if (!label || !value) return;
    var l = label.toLowerCase();
    if (l.includes('member name') || l === 'name') data['Member Name'] = value;
    else if (l.includes('member id') || l.includes('subscriber id') || l === 'id') data['Member ID'] = value;
    else if (l.includes('date of birth') || l.includes('dob') || l.includes('birth')) data['Date of Birth'] = value;
    else if (l.includes('gender') || l.includes('sex')) data['Gender'] = value;
    else if (l.includes('address')) data['Address'] = value;
    else if (l.includes('group number') || l.includes('group #') || l.includes('group id')) data['Group Number'] = value;
    else if (l.includes('plan begin') || l.includes('effective') || l.includes('start date')) data['Plan Begin Date'] = value;
    else if (l.includes('plan name') || l.includes('plan type')) data['Plan Name'] = value;
    else if (l.includes('identifier code') || l.includes('identifier')) data['Identifier Code'] = value;
    else if (l.includes('transaction')) data['Transaction ID'] = data['Transaction ID'] || value;
    else data[label] = value;
  });

  var body = document.body.innerText || '';
  function fill(key, re) {
    if (data[key]) return;
    var m = body.match(re);
    if (m) data[key] = m[1].trim();
  }
  fill('Member Name', /Member Name[:\s]*([^\n]+)/i);
  fill('Member ID', /(?:Member ID|Subscriber ID)[:\s]*([A-Z0-9\-]+)/i);
  fill('Date of Birth', /(?:Date of Birth|DOB)[:\s]*([0-9\/\-]+)/i);
  fill('Gender', /Gender[:\s]*(Male|Female|M|F|Other)/i);
  fill('Address', /Address[:\s]*([^\n]+)/i);
  fill('Group Number', /Group (?:Number|#|ID)[:\s]*([A-Z0-9\-]+)/i);
  fill('Plan Begin Date', /(?:Plan Begin Date|Effective Date|Start Date)[:\s]*([0-9\/\-]+)/i);
  fill('Plan Name', /Plan Name[:\s]*([^\n]+)/i);

  var payerBtn = document.querySelector('button.btn.payer, button.payer, .btn.payer');
  if (payerBtn) {
    var nameEl = payerBtn.querySelector('.fs-18, .fw-500, p:not(.payer__label)');
    if (nameEl) data['Payer'] = nameEl.innerText.trim();
    else {
      var all = payerBtn.innerText.replace(/Payer/i, '').replace(/Active Coverage|Inactive/i, '').trim();
      if (all) data['Payer'] = all;
    }
    var statusEl = payerBtn.querySelector('.payer__status, .payer__coverage');
    if (statusEl) data['Coverage Status'] = statusEl.innerText.trim();
  }
  if (!data['Coverage Status'] && /Active Coverage/i.test(body)) data['Coverage Status'] = 'Active Coverage';
  if (!data['Payer']) {
    var mp = body.match(/Payer[:\s]*([^\n]+)/i);
    if (mp) data['Payer'] = mp[1].replace(/Active Coverage|Inactive/i, '').trim();
  }

  if (!data['Identifier Code']) {
    var idTitle = Array.from(document.querySelectorAll('.subgroup__title, .subgroup__pill, span, div, p, label'))
      .find(function (el) { return /Identifier Code/i.test(el.innerText || '') && (el.innerText || '').trim().length < 40; });
    if (idTitle) {
      var group = idTitle.closest('.subgroup, .summary__group, [class*="subgroup"], [class*="group"]') || idTitle.parentElement;
      if (group) {
        var cands = group.querySelectorAll('.subgroup__value, .summary__value, .fs-14, .fs-16, .fw-500, span, p, div');
        for (var i = 0; i < cands.length; i++) {
          var txt = (cands[i].innerText || '').trim();
          if (txt && !/Identifier Code/i.test(txt) && txt.length > 1 && txt.length < 50) {
            data['Identifier Code'] = txt;
            break;
          }
        }
        if (!data['Identifier Code'] && idTitle.nextElementSibling) {
          var next = (idTitle.nextElementSibling.innerText || '').trim();
          if (next && !/Identifier Code/i.test(next)) data['Identifier Code'] = next;
        }
      }
    }
    if (!data['Identifier Code']) {
      var mi = body.match(/Identifier Code[:\s]*([A-Z0-9\-]+)/i);
      if (mi) data['Identifier Code'] = mi[1].trim();
    }
  }
  return JSON.stringify(data);
})();
